#include<LPC21XX.h>
#include"defines.h"
#include"types.h"
#include"delay.h"
