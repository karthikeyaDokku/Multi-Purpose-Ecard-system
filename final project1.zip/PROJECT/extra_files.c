//if((vote_status)&&(vote_status_check()))





/*int vote_status_check(void)
{
u8* cal;
i2c_eeprom_write(0x50,0X20,0);
vote_status=i2c_eeprom_read(0x50,0X20);
SetCalendar("19/01/2024");
cal=GetCalendar();
if(v_check(cal))
return 1;
else
return 0;
}  */










/*int v_check(u8*cal)
{

int date,month,year,last_voted_date=15,last_voted_month=1,last_voted_year=2013;

date=myatoi(cal[0],cal[1]);

month=myatoi(cal[3],cal[4]);

year=2000+myatoi(cal[8],cal[9]);

if((year-last_voted_year)<5)

{

	return 1;

}

else if(year-last_voted_year==5)

{

	if(month>last_voted_month||(month==last_voted_month&&date>=last_voted_date))

		return 1;

}

return 0;

}
  */
