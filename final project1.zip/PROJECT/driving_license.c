#include<LPC21XX.h>
#include<string.h>
#include<stdlib.h>
#include"defines.h"
#include"types.h"
#include"delay.h"
#include"i2c_defines.h"
#include"i2c_eeprom.h"
#include"lcddefines.h"
#include"i2c.h"

void driving_license(void)
{
	
	u32 choice;
	if(password())
	{
	CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	strLCD("1:USER_DETAILS");
	CmdLCD(GOTO_LINE2_POS0);
	strLCD("2:VALIDITY_CHECK");
	delay_ms(2000);
	CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	strLCD("enter your choice:");
	delay_s(2);
	choice=KeyScan();
	CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	switch(choice)
	{	
				case '1':USER_DETAILS();
				       break;
				case '2':license_validity_check();
					   break;
				case '3':exit(0);
				default:strLCD("invalid input");
	}
	}
}
void USER_DETAILS(void)
{
CmdLCD(CLEAR_LCD);
CmdLCD(GOTO_LINE1_POS0);
strLCD("NAME:");
CmdLCD(GOTO_LINE1_POS0+5);
strLCD("D.SUPRIYA");
CmdLCD(GOTO_LINE2_POS0);
strLCD("COV:");			
CmdLCD(GOTO_LINE2_POS0+4);
strLCD("4-WHEELER");
CmdLCD(GOTO_LINE3_POS0);
strLCD("SR NAGAR,HYD");
CmdLCD(GOTO_LINE4_POS0);
strLCD("TELANGANA");
delay_s(5);
}

void license_validity_check(void)
{
u8 *cal;
SetCalendar("15/01/2024");
strLCD("CHECKING VALIDITY");
delay_s(1); 
cal=GetCalendar();
if(check(cal))
{
   CmdLCD(CLEAR_LCD);
   CmdLCD(GOTO_LINE1_POS0);
   strLCD("valid license");
   delay_s(3); 
}
else
{
	CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	strLCD("Invalid license");
	CmdLCD(GOTO_LINE2_POS0);
	strLCD("Please renew your");
    CmdLCD(GOTO_LINE3_POS0);
	strLCD("license");
	delay_s(3);    
}     
}
